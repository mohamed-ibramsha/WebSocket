package org.example.websock.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}
